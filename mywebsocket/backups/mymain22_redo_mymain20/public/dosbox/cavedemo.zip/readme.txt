Cave Demo (JUSTFLY) by Tom Dobrowolski
Voxlap engine by Ken Silverman

Sept. 7, 2003:

Some people have been begging me to release a Voxlap demo for a while now.
So, Tom and I have come up with a small demo for you... and we hope you
like it! This demo only shows a fraction of Voxlap's features. In this demo,
you will not get to see our latest sprite effects, or some other features
that we may have hinted at in our previous screenshots. We hope to put up a
more complete demo sometime in the future. In addition to the Voxlap engine,
this demo also features some advanced cave-generation tools, designed by Tom.

-Ken S.

-----------------------------------------------------------------------------
Requirements:

   Pentium III, Athlon, or above
   Windows 95/98/ME/NT/2K/XP
   DirectX 8.0
   128MB RAM
   120MB hard disk space

-----------------------------------------------------------------------------
Instructions:

To run the demo, you can use the batch files that we provided. Tom has made 6
sample maps for you to try (RUN1.BAT through RUN6.BAT). The first time you
run one of these batch files, it will take some time to generate the world
map (approximately 1 minute on a 1Ghz machine). Once this file is generated,
the demo will load much faster the next time. If you want to generate all
the maps before viewing them, you can run GENALL.BAT. For more information,
you can run "cavegen" or "justfly" without any parameters.

In the \DATA subdirectory, you will also find a tool that lets you generate
your own textures called CAVETEX. If you make anything interesting with it or
with CAVEGEN, we'd love to see it!

-----------------------------------------------------------------------------
JUSTFLY Controls:

 Arrows     or W,S,A,D Fly forward/back/left/right
 Right Ctrl or F       Fly up
 Keypad 0   or R       Fly down
               Enter   Change weapon (if available)
               Y       Invert mouse
 Caps Lock             Toggle auto-run
 Shift                 Speed up (or slow down with auto-run)
 Left Mouse Button     Fire
 Right Mouse Button    Roll

-----------------------------------------------------------------------------
Please read:

When viewing this demo, please keep in mind that it is the work of just 2
engine programmers, and while we would love to compete with the big game
companies, we realize this is not possible without a complete team of artists,
map designers, producers, etc...

We do hope this demo will generate some interest in voxel engines
(specifically mine :). If the right company comes along, we would be happy to
discuss licensing options. We realize a lot of people have ideas, but we
can't do all the work ourselves. If you can provide us with some talent, we
will be much more likely to be interested in working with you!

-----------------------------------------------------------------------------
Credits:

Tom Dobrowolski (www.carnage.3d.pl):
   Cavegen 3D automatic world generator
   Cavetex texture generator
   Justfly demo
   TX files

Ken Silverman (www.advsys.net/ken):
   Voxlap, 6 degree of freedom voxel engine
   Expression compiler
   WAV files

Further contact information can be found at our websites.
